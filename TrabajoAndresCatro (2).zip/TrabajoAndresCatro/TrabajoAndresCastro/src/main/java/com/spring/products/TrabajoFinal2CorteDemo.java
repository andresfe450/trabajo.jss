package com.spring.products;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabajoFinal2CorteDemo {
}
